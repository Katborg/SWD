﻿namespace Visitor
{
	public interface IViking : IUnit
	{

	}
}