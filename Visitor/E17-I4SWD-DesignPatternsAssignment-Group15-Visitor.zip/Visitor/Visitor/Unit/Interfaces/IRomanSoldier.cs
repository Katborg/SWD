﻿namespace Visitor
{
	public interface IRomanSoldier : IUnit
	{
		
	}
}
