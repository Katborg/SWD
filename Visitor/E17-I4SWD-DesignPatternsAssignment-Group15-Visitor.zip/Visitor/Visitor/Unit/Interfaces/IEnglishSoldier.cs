﻿namespace Visitor
{
	public interface IEnglishSoldier : IUnit
	{
	}
}