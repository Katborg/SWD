﻿namespace Visitor
{
	interface IDefence
	{
		double GetPower();
	}
}