﻿namespace Visitor
{
	public interface IItem
	{
		double GetPower();
	}
}