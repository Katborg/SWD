﻿namespace Visitor
{
	public interface IWeapon
	{
		double GetPower();
	}
}