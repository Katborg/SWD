﻿namespace Visitor
{
	interface IAxe : ITool
	{
		double GetPower();
	}
}