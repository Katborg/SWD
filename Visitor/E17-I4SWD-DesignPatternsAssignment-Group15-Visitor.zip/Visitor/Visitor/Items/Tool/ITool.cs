﻿namespace Visitor
{
	interface ITool : IItem
	{
		double GetPower();
	}
}