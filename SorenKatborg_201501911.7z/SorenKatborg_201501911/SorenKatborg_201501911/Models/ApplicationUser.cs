﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace SorenKatborg_201501911.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
	    public string FirstName { get; set; }
	    public string LastName { get; set; }
	    public string DBFnumber { get; set; }

	    public new string Email { get; set; }
	    public string Password { get; set; }
	    public string  Adressline1 { get; set; }
	    public string Adresseline2 { get; set; }
	    public string ZipCode { get; set; }
	    public string City { get; set; }
    }
}
