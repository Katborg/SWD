﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SorenKatborg_201501911.Models
{
	[Serializable]
	public class VarroaCount
	{
		private string _ownerHive;
		private DateTime _date;
		private string _comments;
		private string _amountOfVarroamider;

		public VarroaCount(string owner, DateTime date, string amountOfVarroamider, string comments, string observationsvarihed)
		{
			_ownerHive = owner;
			_date = date;
			AmountOfVarroamider = amountOfVarroamider;
			_comments = comments;
			Observationsvarihed = observationsvarihed;
		}
		public VarroaCount(string owner, string date, string amountOfVarroamider, string comments, string observationsvarihed)
		{
			_ownerHive = owner;
			_date = DateTime.Parse(date);
			AmountOfVarroamider = amountOfVarroamider;
			_comments = comments;
			Observationsvarihed = observationsvarihed;
		}

		public int ID { get; set; }
		public VarroaCount(string observationsvarihed)
		{
			Observationsvarihed = observationsvarihed;
		}

		public string OwnerHive
		{
			get { return _ownerHive; }

			set
			{

				if (value.Length > 18)
				{
					_ownerHive = "Error Name to long";
					//throw new ApplicationException("Navn må max være 18 karaktere langt");

				}

				_ownerHive = value;

			}
		}

		public string AmountOfVarroamider
		{
			get => _amountOfVarroamider;
			set
			{
				if (value.All(char.IsDigit))
				{
					_amountOfVarroamider = value;

				}
				else
				{
					_amountOfVarroamider = "";
					//throw new ApplicationException("Brug kun tal");
				}
			}
		}

		public string Comments
		{
			get { return _comments; }
			set { _comments = value; }
		}

		public DateTime Date
		{
			get { return _date; }
			set { _date = value; }
		}

		public string Observationsvarihed { get; set; }

	}
}