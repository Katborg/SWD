﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SorenKatborg_201501911.Models.AccountViewModels
{
    public class RegisterViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

	    [Required]
	    [MinLength(2, ErrorMessage = "Initials is not allowed")]
	    [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
		public string FirstName { get; set; }
	    [Required]
	    [MinLength(2, ErrorMessage = "Initials is not allowed")]
	    [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
		public string LastName { get; set; }

	    [Required]
		[MinLength(5),MaxLength(5)]
		[Display(Name = "Dansk Biavler Forening) kontrolnummer (5 cifret nummer)")]
		public string DBFnumber { get; set; }
		[Required]
		public string Adressline1 { get; set; }
	    public string Adresseline2 { get; set; }

	    [Required]
	    [MinLength(4, ErrorMessage = "postnummer er 4 numre"), MaxLength(4)]

	    [RegularExpression(@"^[0-9]+$", ErrorMessage = "Use numbers only please")]
		public string ZipCode { get; set; }
	    [Required]
	    public string City { get; set; }
	}
}
