﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SorenKatborg_201501911.Data;
using SorenKatborg_201501911.Models;

namespace SorenKatborg_201501911.Controllers
{
    public class VarroaCountsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VarroaCountsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: VarroaCounts
        public async Task<IActionResult> Index()
        {
            return View(await _context.VarroaCount.ToListAsync());
        }

        // GET: VarroaCounts/Details/5
        public async Task<IActionResult> Details(int id)
        {
           

            var varroaCount = await _context.VarroaCount
                .SingleOrDefaultAsync(m => m.ID == id);
            if (varroaCount == null)
            {
                return NotFound();
            }

            return View(varroaCount);
        }

        // GET: VarroaCounts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: VarroaCounts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,OwnerHive,AmountOfVarroamider,Comments,Date,Observationsvarihed")] VarroaCount varroaCount)
        {
            if (ModelState.IsValid)
            {
                _context.Add(varroaCount);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(varroaCount);
        }

        // GET: VarroaCounts/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var varroaCount = await _context.VarroaCount.SingleOrDefaultAsync(m => m.ID == id);
            if (varroaCount == null)
            {
                return NotFound();
            }
            return View(varroaCount);
        }

        // POST: VarroaCounts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,OwnerHive,AmountOfVarroamider,Comments,Date,Observationsvarihed")] VarroaCount varroaCount)
        {
            if (id != varroaCount.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(varroaCount);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VarroaCountExists(varroaCount.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(varroaCount);
        }

        // GET: VarroaCounts/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var varroaCount = await _context.VarroaCount
                .SingleOrDefaultAsync(m => m.ID == id);
            if (varroaCount == null)
            {
                return NotFound();
            }

            return View(varroaCount);
        }

        // POST: VarroaCounts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var varroaCount = await _context.VarroaCount.SingleOrDefaultAsync(m => m.ID == id);
            _context.VarroaCount.Remove(varroaCount);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VarroaCountExists(int id)
        {
            return _context.VarroaCount.Any(e => e.ID == id);
        }
    }
}
