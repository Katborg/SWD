﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

/*Ide af Nicholas fra løsning af Agent opgaverne*/

namespace _201501911_SorenKatborg
{
	public class Time : INotifyPropertyChanged
	{
		private static Timer x;
		private string _Date;

		public Time()
		{
			x = new Timer(1000);
			x.Interval = 1000;
			x.Elapsed += SetDate;
			x.Enabled = true;
		}

		private void SetDate(object sender, ElapsedEventArgs e)
		{
			Date = System.DateTime.Now.ToString("F");
		}



		public string Date
		{
			get => _Date;
			set
			{
				if (value != _Date)
				{
					_Date = value;
					Notify();
				}
			}
		}

		#region INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;
		protected void
			Notify([CallerMemberName]string propName = null
			)
		{
			var handler
				= PropertyChanged;
			if (handler != null)
			{
				handler(this
					, new PropertyChangedEventArgs(propName));
			}
		}
		#endregion



	}
}
