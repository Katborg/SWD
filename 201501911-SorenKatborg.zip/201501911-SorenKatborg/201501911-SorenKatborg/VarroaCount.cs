﻿using System;
using System.Collections;
using System.Linq;

namespace _201501911_SorenKatborg
{
	[Serializable]
	public class VarroaCount
	{
		private string _ownerHive;
		private DateTime _date;
		private string _comments;
		private string _amountOfVarroamider;

		public VarroaCount(string owner, DateTime date, string amountOfVarroamider, string comments)
		{
			_ownerHive = owner;
			_date = date;
			AmountOfVarroamider = amountOfVarroamider;
			_comments = comments;
		}
		public VarroaCount(string owner, string date, string amountOfVarroamider, string comments)
		{
			_ownerHive = owner;
			_date = DateTime.Parse(date);
			AmountOfVarroamider = amountOfVarroamider;
			_comments = comments;
		}
		public VarroaCount()
		{
			
		}

		public string OwnerHive
		{
			get { return _ownerHive; }
			
			set
			{

				if (value.Length > 18)
				{
					_ownerHive = "Error Name to long";
					throw new ApplicationException("Navn må max være 18 karaktere langt");
					
				}
				
				_ownerHive = value;
				
			}
		}

		public string AmountOfVarroamider
		{
			get => _amountOfVarroamider;
			set
			{
				if (value.All(char.IsDigit))
				{
					_amountOfVarroamider = value;

				}
				else
				{
					_amountOfVarroamider = "";
					throw new ApplicationException("Brug kun tal");
				}
			}
		}

		public string Comments
		{
			get { return _comments; }
			set { _comments = value; }
		}

		public DateTime Date
		{
			get { return _date; }
			set { _date = value; }
		}

		
	}
}