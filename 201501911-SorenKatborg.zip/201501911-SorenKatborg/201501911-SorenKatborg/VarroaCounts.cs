﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Xml.Serialization;
using _201501911_SorenKatborg.Properties;

namespace _201501911_SorenKatborg
{

	//Mange af komandoerne er kraftigt inspireret af Agent opgaverne. 
	public class VarroaCounts : ObservableCollection<VarroaCount>, INotifyPropertyChanged
	{
		private String _name;
		private List<VarroaCount> listVarroaCounts;

		public VarroaCounts()
		{
			//Add(new VarroaCount("Røgen bistaden", DateTime.Parse("08-07-2017"), "6"," Kommentar "));
			//Add(new VarroaCount("Nordre bistad", DateTime.Parse("08-07-2017"), "2", " Anden ting"));
			//Add(new VarroaCount("Røgen bistad", DateTime.Parse("15-07-2017"), "10", "Notat "));

		


		}

		#region Properties

		//Taget fra Agent opgaven

		

		string filename = "";

		private int _currentIndex = 0;

		public int CurrentIndex
		{
			get { return _currentIndex; }
			set
			{
				if (_currentIndex != value)
				{
					_currentIndex = value;
					Notify();
				}
			}
		}

		#endregion

		#region Command

		#region NextCommand

		private ICommand _NextCommand;

		public ICommand NextCommand
		{
			get
			{
				return _NextCommand ?? (_NextCommand = new RelayCommand(
						   () => ++CurrentIndex,
						   () => CurrentIndex < this.Count - 1
					   ));
			}
		}


		/*	ICommand _nextCommand;
		public ICommand NextCommand
		{
			get
			{
				return _nextCommand ?? (_nextCommand = new RelayCommand(
					       () => ++CurrentIndex,
					       () => CurrentIndex < (Count - 1)));
			}
		}*/

		/*private ICommand _nextCommand;
		public ICommand NextCommand
		{
			get
			{
				return _nextCommand ?? (_nextCommand = new RelayCommand(
						   NextCommandExecute, // the command
						   NextCommandCanExecute)); //Test if command should be run
			}
		}

		private void NextCommandExecute()
		{
			CurrentIndex++;
		}

		private bool NextCommandCanExecute()
		{
			if (CurrentIndex < (Count - 1))
			{
				return true;
			}

			return false;
		}*/
		#endregion

		#region PreviusCommand
		private ICommand _PreviusCommand;
		public ICommand PreviusCommand
		{
			get
			{
				return _PreviusCommand ?? (_PreviusCommand = new RelayCommand(
						   PreviusCommandExecute, // the command
						   PreviusCommandCanExecute));  //Test if command should be run
			}
		}

		private void PreviusCommandExecute()
		{
			CurrentIndex--;
		}

		private bool PreviusCommandCanExecute()
		{
			if (CurrentIndex > 0)
			{
				return true;
			}

			return false;
		}
		#endregion

		#region AddCommand
		public ICommand AddCommand
		{
			get
			{
				return new RelayCommand(
					AddCommandExecute); // the command

			}
		}

		private void AddCommandExecute()
		{
			VarroaCount tempCount = new VarroaCount();

			NewCountWindows newCountWindows = new NewCountWindows();
			
			if (newCountWindows.ShowDialog() == true)
			{
				//Set Owner Hive if no exeption.
				try
					{
						tempCount.OwnerHive = newCountWindows.TextBlockOwnerHive.Text;
					}
					catch (Exception e)
					{
						tempCount.OwnerHive = "Error";
					}
				
				//set date 
				if (newCountWindows.calendar.SelectedDate != null)
					tempCount.Date = newCountWindows.calendar.SelectedDate.Value;
					else
					{
						tempCount.Date = DateTime.Now;
					}

				//Set amout of Varroamider
				try
					{
						tempCount.AmountOfVarroamider = newCountWindows.TextBlockAmountOgVarroamider.Text;
					}
					catch (Exception e)
					{
					tempCount.AmountOfVarroamider = "0";
					}

				//Set Comments
				tempCount.Comments = newCountWindows.TextBlockComments.Text;

				//Add
				Add(tempCount);
				CurrentIndex = Count - 1;
			}

			
		}

		#endregion

		#region DeleteCommand
		public ICommand DeleteCommand
		{
			get
			{
				return new RelayCommand(
					DeleteCommandExecute, // the command
					DeleteCommandCanExecute);  //Test if command should be run
			}
		}

		private void DeleteCommandExecute()
		{
			RemoveAt(CurrentIndex);
		}

		private bool DeleteCommandCanExecute()
		{
			if (Count > 0 && CurrentIndex >= 0)
				return true;
			else
				return false;
		}
		#endregion


		#region SaveAsCommad

		ICommand _SaveAsCommand;
		public ICommand SaveAsCommand
		{
			get { return _SaveAsCommand ?? (_SaveAsCommand = new RelayCommand<string>(SaveAsCommand_Execute)); }
		}

		private void SaveAsCommand_Execute(string argFilename)
		{
			if (argFilename == "")
			{
				MessageBox.Show("You must enter a file name in the File Name textbox!", "Unable to save file",
					MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				filename = argFilename;
				SaveFileCommand_Execute();
				Settings.Default.LastUsedFile = filename;
				Settings.Default.Save();
			}
		}
		#endregion

		#region SaveFileCommand

		ICommand _SaveCommand;
		public ICommand SaveCommand
		{
			get { return _SaveCommand ?? (_SaveCommand = new RelayCommand(SaveFileCommand_Execute, SaveFileCommand_CanExecute)); }
		}

		private void SaveFileCommand_Execute()
		{
			// Create an instance of the XmlSerializer class and specify the type of object to serialize.
			XmlSerializer serializer = new XmlSerializer(typeof(VarroaCounts));
			TextWriter writer = new StreamWriter(filename);
			// Serialize all the VerroaCounts.
			serializer.Serialize(writer, this);
			writer.Close();
		}

		private bool SaveFileCommand_CanExecute()
		{
			return (filename != "") && (Count > 0);
		}

		#endregion

		#region NewFile

		ICommand _NewFileCommand;
		public ICommand NewFileCommand
		{
			get { return _NewFileCommand ?? (_NewFileCommand = new RelayCommand(NewFileCommand_Execute)); }
		}

		private void NewFileCommand_Execute()
		{
			MessageBoxResult res = MessageBox.Show("Any unsaved data will be lost. Are you sure you want to initiate a new file?", "Warning",
				MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
			if (res == MessageBoxResult.Yes)
			{
				Clear();
				filename = "";
			}
		}


		#endregion

		#region OpenFileCommand

		ICommand _OpenFileCommand;
		public ICommand OpenFileCommand
		{
			get { return _OpenFileCommand ?? (_OpenFileCommand = new RelayCommand<string>(OpenFileCommand_Execute)); }
		}

		private void OpenFileCommand_Execute(string argFilename)
		{
			if (argFilename == "")
			{

				MessageBox.Show("You must enter a file name in the File Name textbox!", "Unable to save file",
					MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				filename = argFilename;
				VarroaCounts tempVarroaCount = new VarroaCounts();

				// Create an instance of the XmlSerializer class and specify the type of object to deserialize.
				XmlSerializer serializer = new XmlSerializer(typeof(VarroaCounts));
				try
				{
					TextReader reader = new StreamReader(filename);
					// Deserialize all the varroaCounts.
					tempVarroaCount = (VarroaCounts)serializer.Deserialize(reader);
					reader.Close();
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Unable to open file", MessageBoxButton.OK, MessageBoxImage.Error);
				}

				// We have to insert the VarroaCounts in the existing collection. 
				Clear();
				foreach (var varroaCount in tempVarroaCount)
					Add(varroaCount);
			}
		}

		#endregion

		#endregion

		#region INotifyPropertyChanged implementation

		//Taget fra Agent opgaven

		public event PropertyChangedEventHandler PropertyChanged;
		protected void
			Notify([CallerMemberName]string propName = null
			)
		{
			var handler
				= PropertyChanged;
			if (handler != null)
			{
				handler(this
					, new PropertyChangedEventArgs(propName));
			}
		}
		#endregion

	}
}
