﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _201501911_SorenKatborg.Properties;

namespace _201501911_SorenKatborg
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			

			CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ListBoxVerroaCounts.ItemsSource);
			view.Filter = HiveFilter;
			
			
		}


		private bool HiveFilter(object item)
		{
			if (String.IsNullOrEmpty(tbxFilter.Text))
				return true;
			else
				return (item.ToString().IndexOf(tbxFilter.Text, StringComparison.OrdinalIgnoreCase) >= 0);
		}

		private void txtFilter_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
		{
			string filterstring = tbxFilter.Text;
			CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ListBoxVerroaCounts.ItemsSource);

			view.Filter = filter =>
			{
				VarroaCount temp = filter as VarroaCount;
				return temp.OwnerHive.Contains(filterstring);
			};
		}
	}
}
